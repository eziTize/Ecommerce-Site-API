<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Validator;
use DB;
use Illuminate\Support\Str;

class SiteLanguage extends Model
{
	protected $table = "ig_site_language";
}
